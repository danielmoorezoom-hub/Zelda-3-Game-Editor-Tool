@echo off
REM Zelda3 Game Editor - opens the save / warp / enemy editor in your browser.
cd /d "%~dp0.."
if exist "assets\python.exe" (
  "assets\python.exe" "game_editor\zelda3_game_editor.py" %*
) else (
  python "game_editor\zelda3_game_editor.py" %*
)
if errorlevel 1 pause
