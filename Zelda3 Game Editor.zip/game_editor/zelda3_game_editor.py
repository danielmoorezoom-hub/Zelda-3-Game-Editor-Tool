#!/usr/bin/env python3
"""
Zelda3 Game Editor
==================
Edit save files (progress, inventory), quick-save states (with warping) and
enemy stats for the snesrev zelda3 reimplementation.

  zelda3_game_editor.py [--game DIR] [--port N] [--no-browser]

Only needs Python 3 (standard library).
"""
import glob
import json
import os
import re
import shutil
import struct
import sys
import threading
import time
import urllib.parse
import urllib.request

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
TOOL_VERSION = "1.0"
DEFAULT_PORT = 47824

GAMEDATA = json.loads(r"""{"entrances":["Link's House Intro","Link's House Post-intro","Sanctuary","Hyrule Castle West","Hyrule Castle Central","Hyrule Castle East","Death Mountain Express (Lower)","Death Mountain Express (Upper)","Eastern Palace","Desert Palace Central","Desert Palace East","Desert Palace West","Desert Palace Boss Lair","Kakariko Elder's House West","Kakariko Elder's House East","Kakariko Angry Bros West","Kakariko Angry Bros East","Mad Batter Lair","Under Lumberjacks' Weird Tree","Death Mountain Maze 0000","Death Mountain Maze 0001","Turtle Rock Mountainface 1","Death Mountain Cape Heart Piece Cave (Lower)","Death Mountain Cape Heart Piece Cave (Upper)","Turtle Rock Mountainface 2","Turtle Rock Mountainface 3","Death Mountain Maze 0002","Death Mountain Maze 0003","Death Mountain Maze 0004","Death Mountain Maze 0005","Death Mountain Maze 0006","Death Mountain Maze 0007","Death Mountain Maze 0008","Spectacle Rock Maze 1","Spectacle Rock Maze 2","Spectacle Rock Maze 3","Hyrule Castle Tower","Swamp Palace","Palace of Darkness","Misery Mire","Skull Woods 1","Skull Woods 2","Skull Woods Big Chest","Skull Woods Boss Lair","Lost Woods Thieves' Lair","Ice Palace","Death Mountain Escape West","Death Mountain Escape East","Death Mountain Elder's Cave (Lower)","Death Mountain Elder's Cave (Upper)","Hyrule Castle Secret Cellar","Tower of Hera","Thieves's Town","Turtle Rock Main","Ganon's Pyramid Sanctum (Lower)","Ganon's Tower","Fairy Cave 1","Kakariko Western Well","Death Mountain Maze 0009","Death Mountain Maze 0010","Treasure Shell Game 1","Storyteller Cave 1","Snitch House 1","Snitch House 2","SickBoy House","Byrna Gauntlet","Kakariko Pub South","Kakariko Pub North","Kakariko Inn","Sahasrahlah's Disco Infernum","Kakariko's Lame Shop","Village of Outcasts Chest Game","Village of Outcasts Orphanage","Kakariko Library","Kakariko Storage Shed","Kakariko Sweeper Lady's House","Potion Shop","Aginah's Desert Cottage","Watergate","Death Mountain Maze 0011","Fairy Cave 2","Refill Cave 0001","Refill Cave 0002","The Bomb \"Shop\"","Village of Outcasts Retirement Center","Fairy Cave 3","Good Bee Cave","General Store 1","General Store 2","Archery Game","Storyteller Cave 2","Hall of the Invisibility Cape","Pond of Wishing","Pond of Happiness","Fairy Cave 4","Swamp of Evil Heart Piece Hall","General Store 3","Blind's Old Hideout","Storyteller Cave 3","Warped Pond of Wishing","Chez Smithies","Fortune Teller 1","Fortune Teller 2","Chest Shell Game 2","Storyteller Cave 4","Storyteller Cave 5","Storyteller Cave 6","Village House 1","Thief Hideout 1","Thief Hideout 2","Heart Piece Cave 1","Thief Hideout 3","Refill Cave 3","Fairy Cave 5","Heart Piece Cave 2","Hyrule Castle Prison","Hyrule Castle Throne Room","Hyrule Tower Agahnim's Sanctum","Skull Woods 3 (Drop In)","Skull Woods 4 (Drop In)","Skull Woods 5 (Drop In)","Skull Woods 6 (Drop In)","Lost Woods Thieves' Hideout (Drop In)","Ganon's Pyramid Sanctum (Upper)","Fairy Cave 6 (Drop In)","Hyrule Castle Secret Cellar (Drop In)","Mad Batter Lair (Drop In)","Under Lumberjacks' Weird Tree (Drop In)","Kakariko Western Well (Drop In)","Hyrule Sewers Goodies Room (Drop In)","Chris Houlihan Room (Drop In)","Heart Piece Cave 3 (Drop In)","Ice Rod Cave"],"sprites":["00-Raven","01-Vulture","02","03-BigCanon","04-PullSwitch","05-DnSwitch","06-TrapSwitch","07-FloorMove","08-Octorok","09-Mouldrum","0A-4WayOctorok","0B-Chicken","0C-HoveringRock","0D-Cucumber","0E-SnapDragon","0F-OctoBlimp","10","11-Hinox","12-PigSpearMan","13-MiniHelmasaur","14-GargoyleGrate","15-Bubble","16-Mutant","17-BushCrab","18-Moldorm","19-Poe/Ghini","1A-BlackSmith(Frog","1B-AnArrow","1C-Statue","1D-UselessSprite","1E-PegSwitch","1F-SickBoy","20-BombSlug","21-PushSwitch","22-HoppingBulbPlan","23-RedMiri","24-BlueMiri","25-LiveTree","26-BlueOrb","27-Squirrel","28-PersonRm270","29-Thief","2A-DustGirl","2B-TentMan","2C-Lumberjacks","2D","2E-FluteBoy","2F-Person","30-Person","31-FortuneTeller","32-AngryBrother","33-PullForRupees","34-ScaredGirl2","35-HedgeMan","36-Witch","37-Waterfall","38-ArrowTarget","39-GuyByTheSign","3A-Person11_227","3B-DashItem","3C-FarmBoy","3D-ScaredGirl1","3E-RockCrab","3F-PalaceGuard","40-ElectricBarrier","41-BlueSoldier","42-GreenSoldier","43-RedSpearSoldier","44-Warrior","45-HogSpearMan","46-BlueArcher","47-GreenGrassArche","48-RedSpearKnight","49-RedGrassSpearSo","4A-RedBombKnight","4B-Knight","4C-Geldman","4D-Bunny","4E-Tentacle2","4F-Tentacle","50-GlassSquirrel","51-Armos","52-ZoraKing","53-ArmosKnight","54-Lanmolas","55-FireBallZora","56-WalkingZora","57-HyliaObstacle","58-Crab","59-Animal","5A-Animal","5B-WallBubble(L-R)","5C-WallBubble(R-L)","5D-Roller_1","5E-Roller_2","5F-Roller_3","60-Roller_4","61-Beamos","62-MasterSwd","63-SandCrab1","64-SandCrab2","65-ArcherGame","66-Cannon(Right)","67-Cannon(Left)","68-Cannon(Down)","69-Cannon(Up)","6A-MorningStar","6B-CannonSoldier","6C-Teleport","6D-Rat","6E-Rope","6F-Keese","70","71-Leever","72-Pond","73-Priest/Uncle","74-Runner","75-BottleMan","76-Zelda","77-WierdBuble","78-OldWoman","79-Bee","7A-Agahnim","7B-OneShotMagicBal","7C-StalfosHead","7D-BigSpikeBlock","7E-FireBlade","7F-FireBlade2","80-Lanmola","81-WaterBug","82-4Bubbles","83-GreenRocklops","84-RedRocklops","85-BigSpikeBlock","86-Triceritops","87-FireKeese","88-Mothula","89","8A-SpikeBlock","8B-Gibdo","8C-Arrghus","8D-ArrghusFuzz","8E-Shell","8F-Blob","90-WallMaster","91-StalfosKnight","92-Helmasaur","93-RedOrb","94","95-EyeLaser(Right)","96-EyeLaser(Left)","97-EyeLaser(Down)","98-EyeLaser(Up)","99-Penguin","9A-Splash","9B-Wizzrobe","9C","9D-VRat","9E-Ostrich","9F-Rabbit","A0-Uglybird","A1-IceMan","A2-KholdStare","A3","A4","A5-GreenLizard","A6-RedLizard","A7-Stalfos","A8-GreenAirBomber","A9-BlueAirBomber","AA-LikeLike","AB","AC-Apples","AD-OldMan","AE-DownPipe","AF-UpPipe","B0-RightPipe","B1-LeftPipe","B2-Good-Bee","B3-Inscription","B4-BlueChest","B5-BombShop","B6-Kiki","B7-BlindMan","B8","B9-Bully&Whimp(DW)","BA-Whirlpool","BB-ShopMan","BC-OldMan2","BD-Viterous","BE-","BF-Lighting","C0-Item","C1-AgahTalk","C2-RockChip","C3-Half-Bubble","C4-Bully","C5-Shooter","C6-4WayShooter","C7-FuzzyStack","C8-BigFairy","C9-Tektite","CA-Chomp","CB-TriNexx1","CC-TriNexx2","CD-TriNexx3","CE-Blind","CF-SwampSnake","D0-Lynel","D1-Transform/Smoke","D2-Fish","D3-AliveRock","D4-GroundBomb","D5-DiggingGameGuy","D6-Ganon","D7","D8-Heart","D9-Rupee-G","DA-Rupee-B","DB-InTreeRocks","DC-Bomb","DD-4_bombs","DE-8_bombs","DF-Magic","E0-BigMagic","E1-Arrow","E2-10-Arrows","E3-Fairy","E4-Key","E5-Big_Key","E6","E7-Mushroom","E8-FakeSword","E9-ShopMan2","EA-WitchAssistant","EB-HeartPie","EC-PickedObj","ED","EE-Mantle","EF","F0","F1","F2-MedallianTablet"],"sig":{"kSpriteInit_Health":"0c06ff0303030303020c04ff00030c020014040400ff0002030800000000000008030802020003ff0003030303030303030003000303030003000000000302ff02060408060806040808080404020202ff08ff30100808ff020000ffffffffffffffffff0404ffffffff100300020401ff04ff00000000ff000060ff18ffffff0304ff10080800ff2020202020080804084030ff02ffffffff10040204040808081040400804080404080c1000000000000000000000000000000000008030ffffffff08000000200008052828285a10184000040000ffff000000000000000000000000000000000000000000000000000000","kSpriteInit_BumpDamage":"838381020202020201130101010108010108050340040002038500010040000006000503010000030000000000000000000000000000004000000000000002020001010301030101030303010301010101010111140101020500000404080808080400040302020202020301000001800501000000400004000014040604040404030404040104041505040515150305000515050506060606050306050503030306171515050501858305040000000000000000000000000000000000171705050504030210000600050717171715070610000303001919000000000000000000000010000000000000000000000000000000","kPlayerDamages":"020101040404000000080402080808100804201008201810181008403018","kEnemyDamages":"000120fffcfb000000024004000000000004400203000000000840040000000000104008000000000010400800000000000440100000000000ff40fffcfb0000000440fffcfb2000006418640000000000f9faff64000000000840fd04100000000840fe04000000001040fd0000000000fe401000000000002040ff000000fa"}}""")
ENTRANCE_NAMES = GAMEDATA["entrances"]
SPRITE_NAMES = GAMEDATA["sprites"]
EXE_SIGNATURES = {k: bytes.fromhex(v) for k, v in GAMEDATA["sig"].items()}

# ----------------------------------------------------------------------------
# zelda3_assets.dat
# ----------------------------------------------------------------------------

class AssetFile:
    def __init__(self, path):
        self.path = path
        data = open(path, "rb").read()
        if not data.startswith(b"Zelda3_v0"):
            raise ValueError("%s is not a zelda3 asset file" % path)
        self.header = data[:80]
        n, klen = struct.unpack_from("<II", data, 80)
        sizes = struct.unpack_from("<%dI" % n, data, 88)
        self.key_blob = data[88 + 4 * n: 88 + 4 * n + klen]
        self.names = [k.decode() for k in self.key_blob.split(b"\0")[:-1]]
        off = 88 + 4 * n + klen
        self.blobs = {}
        for k, s in zip(self.names, sizes):
            off = (off + 3) & ~3
            self.blobs[k] = bytes(data[off: off + s])
            off += s

    def get(self, name):
        return self.blobs[name]

    def words(self, name):
        b = self.blobs[name]
        return list(struct.unpack("<%dH" % (len(b) // 2), b))

    def serialize(self):
        n = len(self.names)
        out = bytearray(self.header)
        out += struct.pack("<II", n, len(self.key_blob))
        out += struct.pack("<%dI" % n, *[len(self.blobs[k]) for k in self.names])
        out += self.key_blob
        for k in self.names:
            while len(out) & 3:
                out.append(0)
            out += self.blobs[k]
        return bytes(out)


def backup_once(path, suffix=".orig"):
    b = path + suffix
    if os.path.exists(path) and not os.path.exists(b):
        shutil.copy2(path, b)
        return os.path.basename(b)
    return None


def write_atomic(path, data):
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, path)


# ----------------------------------------------------------------------------
# Save data layout (offsets inside a 0x500-byte save slot; in RAM it lives at 0x7EF000)
# ----------------------------------------------------------------------------

DUNGEONS = ["Sewers / Hyrule Castle", "Hyrule Castle", "Eastern Palace", "Desert Palace", "Castle Tower",
            "Swamp Palace", "Palace of Darkness", "Misery Mire", "Skull Woods", "Ice Palace",
            "Tower of Hera", "Thieves' Town", "Turtle Rock", "Ganon's Tower"]
KEY_DUNGEONS = [0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]   # index 1 shares keys with 0

YESNO = ["No", "Yes"]
FIELDS = [
    # key, label, group, offset, type, options/max
    ("sword", "Sword", "Equipment", 0x359, "sel", ["None", "Fighter's sword", "Master sword", "Tempered sword", "Golden sword"]),
    ("shield", "Shield", "Equipment", 0x35A, "sel", ["None", "Fighter's shield", "Fire shield", "Mirror shield"]),
    ("armor", "Armor", "Equipment", 0x35B, "sel", ["Green mail", "Blue mail", "Red mail"]),
    ("gloves", "Gloves", "Equipment", 0x354, "sel", ["None", "Power glove", "Titan's mitt"]),
    ("boots", "Pegasus boots", "Equipment", 0x355, "sel", YESNO),
    ("flippers", "Zora's flippers", "Equipment", 0x356, "sel", YESNO),
    ("pearl", "Moon pearl", "Equipment", 0x357, "sel", YESNO),

    ("bow", "Bow", "Items", 0x340, "sel", ["None", "Bow", "Bow & arrows", "Silver bow", "Silver bow & arrows"]),
    ("boomerang", "Boomerang", "Items", 0x341, "sel", ["None", "Blue boomerang", "Red boomerang"]),
    ("hookshot", "Hookshot", "Items", 0x342, "sel", YESNO),
    ("mushroom", "Mushroom / Powder", "Items", 0x344, "sel", ["None", "Mushroom", "Magic powder"]),
    ("firerod", "Fire rod", "Items", 0x345, "sel", YESNO),
    ("icerod", "Ice rod", "Items", 0x346, "sel", YESNO),
    ("bombos", "Bombos", "Items", 0x347, "sel", YESNO),
    ("ether", "Ether", "Items", 0x348, "sel", YESNO),
    ("quake", "Quake", "Items", 0x349, "sel", YESNO),
    ("lamp", "Lamp", "Items", 0x34A, "sel", YESNO),
    ("hammer", "Magic hammer", "Items", 0x34B, "sel", YESNO),
    ("flute", "Shovel / Flute", "Items", 0x34C, "sel", ["None", "Shovel", "Flute", "Flute (bird active)"]),
    ("net", "Bug-catching net", "Items", 0x34D, "sel", YESNO),
    ("book", "Book of Mudora", "Items", 0x34E, "sel", YESNO),
    ("somaria", "Cane of Somaria", "Items", 0x350, "sel", YESNO),
    ("byrna", "Cane of Byrna", "Items", 0x351, "sel", YESNO),
    ("cape", "Magic cape", "Items", 0x352, "sel", YESNO),
    ("mirror", "Magic mirror", "Items", 0x353, "sel", ["None", "Magic scroll (unused)", "Magic mirror"]),

    ("bottle1", "Bottle 1", "Bottles", 0x35C, "sel", None),
    ("bottle2", "Bottle 2", "Bottles", 0x35D, "sel", None),
    ("bottle3", "Bottle 3", "Bottles", 0x35E, "sel", None),
    ("bottle4", "Bottle 4", "Bottles", 0x35F, "sel", None),

    ("hearts", "Heart containers", "Stats", 0x36C, "hearts", 20),
    ("health", "Current health", "Stats", 0x36D, "hearts", 20),
    ("heartpieces", "Heart pieces (toward next)", "Stats", 0x36B, "num", 3),
    ("magic", "Magic (0-128)", "Stats", 0x36E, "num", 128),
    ("magicup", "Magic upgrade", "Stats", 0x37B, "sel", ["Normal", "Half magic", "Quarter magic"]),
    ("rupees", "Rupees", "Stats", 0x362, "u16", 9999),
    ("bombs", "Bombs", "Stats", 0x343, "num", 99),
    ("bombup", "Bomb capacity upgrades", "Stats", 0x370, "num", 7),
    ("arrows", "Arrows", "Stats", 0x377, "num", 99),
    ("arrowup", "Arrow capacity upgrades", "Stats", 0x371, "num", 7),

    ("progress", "Story progress", "Progress", 0x3C5, "sel",
     ["0 - New game (in bed)", "1 - Have uncle's sword", "2 - Zelda rescued", "3 - Agahnim defeated"]),
    ("world", "World", "Progress", 0x3CA, "sel", {"0": "Light World", "64": "Dark World"}),
    ("start", "Continue point", "Progress", 0x3C8, "sel", None),
    ("mapicons", "Map marker stage", "Progress", 0x3C7, "num", 255),
    ("follower", "Follower", "Progress", 0x3CC, "sel",
     {"0": "None", "1": "Zelda", "4": "Old man", "6": "Blind's maiden", "7": "Frog (smithy)", "8": "Smithy",
      "9": "Locksmith chest", "10": "Kiki", "12": "Purple chest", "13": "Super bomb"}),
    ("progflags", "Story flags (advanced)", "Progress", 0x3C6, "bits8", None),
    ("pendants", "Pendants", "Pendants", 0x374, "bits8",
     [[4, "Courage (green, Eastern)"], [2, "Power (blue, Desert)"], [1, "Wisdom (red, Hera)"]]),
    ("crystals", "Crystals", "Crystals", 0x37A, "bits8",
     [[2, "1 · Palace of Darkness"], [16, "2 · Swamp Palace"], [64, "3 · Skull Woods"], [32, "4 · Thieves' Town"],
      [4, "5 · Ice Palace"], [1, "6 · Misery Mire"], [8, "7 · Turtle Rock"]]),
]
BOTTLE_OPTS = {"0": "No bottle", "2": "Empty bottle", "3": "Red potion", "4": "Green potion", "5": "Blue potion",
               "6": "Fairy", "7": "Bee", "8": "Good bee", "1": "Mushroom (unused)"}
ABILITY_DASH, ABILITY_SWIM = 0x04, 0x02


def field_meta(start_names):
    out = []
    for key, label, group, off, typ, opts in FIELDS:
        if key.startswith("bottle"):
            opts = BOTTLE_OPTS
        if key == "start":
            opts = {str(i): n for i, n in enumerate(start_names)}
        out.append({"key": key, "label": label, "group": group, "off": off, "type": typ, "opts": opts})
    return out


def read_fields(buf, base):
    v = {}
    for key, label, group, off, typ, opts in FIELDS:
        if typ == "u16":
            v[key] = struct.unpack_from("<H", buf, base + off)[0]
        elif typ == "hearts":
            v[key] = buf[base + off] / 8.0
        else:
            v[key] = buf[base + off]
    v["dungeons"] = []
    mp, cp, bk = (struct.unpack_from("<H", buf, base + o)[0] for o in (0x368, 0x364, 0x366))
    for d, name in enumerate(DUNGEONS):
        m = 0x8000 >> d
        v["dungeons"].append({"name": name, "map": bool(mp & m), "compass": bool(cp & m), "bigkey": bool(bk & m),
                              "keys": buf[base + 0x37C + d] if d in KEY_DUNGEONS else None})
    v["abilities"] = buf[base + 0x379]
    return v


def write_fields(buf, base, v):
    for key, label, group, off, typ, opts in FIELDS:
        if key not in v:
            continue
        x = v[key]
        if typ == "u16":
            x = max(0, min(int(x), opts))
            struct.pack_into("<H", buf, base + off, x)
            if key == "rupees":
                struct.pack_into("<H", buf, base + 0x360, x)   # displayed counter target
        elif typ == "hearts":
            x = max(0, min(int(round(float(x) * 8)), 20 * 8))
            buf[base + off] = x
        else:
            buf[base + off] = max(0, min(int(x), 255))
    # keep health within capacity
    if buf[base + 0x36D] > buf[base + 0x36C]:
        buf[base + 0x36D] = buf[base + 0x36C]
    # abilities follow boots / flippers
    ab = buf[base + 0x379]
    ab = (ab | ABILITY_DASH) if buf[base + 0x355] else (ab & ~ABILITY_DASH)
    ab = (ab | ABILITY_SWIM) if buf[base + 0x356] else (ab & ~ABILITY_SWIM)
    buf[base + 0x379] = ab & 0xFF
    # bottle selector
    bottles = [buf[base + 0x35C + i] for i in range(4)]
    sel = buf[base + 0x34F]
    if not any(bottles):
        buf[base + 0x34F] = 0
    elif sel == 0 or sel > 4 or not bottles[sel - 1]:
        buf[base + 0x34F] = next(i + 1 for i, b in enumerate(bottles) if b)
    if "dungeons" in v:
        mp = cp = bk = 0
        for d, dv in enumerate(v["dungeons"][:len(DUNGEONS)]):
            m = 0x8000 >> d
            mp |= m if dv.get("map") else 0
            cp |= m if dv.get("compass") else 0
            bk |= m if dv.get("bigkey") else 0
            if d in KEY_DUNGEONS and dv.get("keys") is not None:
                buf[base + 0x37C + d] = max(0, min(int(dv["keys"]), 99))
        old = [struct.unpack_from("<H", buf, base + o)[0] for o in (0x368, 0x364, 0x366)]
        # keep bits beyond the 14 named dungeons untouched
        keep = 0xFFFF >> len(DUNGEONS)
        struct.pack_into("<H", buf, base + 0x368, (old[0] & keep) | mp)
        struct.pack_into("<H", buf, base + 0x364, (old[1] & keep) | cp)
        struct.pack_into("<H", buf, base + 0x366, (old[2] & keep) | bk)


def max_out(v):
    v.update(sword=4, shield=3, armor=2, gloves=2, boots=1, flippers=1, pearl=1, bow=4, boomerang=2, hookshot=1,
             mushroom=2, firerod=1, icerod=1, bombos=1, ether=1, quake=1, lamp=1, hammer=1, flute=3, net=1, book=1,
             somaria=1, byrna=1, cape=1, mirror=2, bottle1=6, bottle2=5, bottle3=8, bottle4=4, hearts=20, health=20,
             magic=128, magicup=2, rupees=999, bombup=7, arrowup=7, bombs=50, arrows=70)
    return v


# ----------------------------------------------------------------------------
# saves/sram.dat
# ----------------------------------------------------------------------------

class SaveFile:
    SLOT = 0x500

    def __init__(self, path):
        self.path = path
        self.data = bytearray(open(path, "rb").read()) if os.path.exists(path) else bytearray(0x2000)
        if len(self.data) != 0x2000:
            raise ValueError("saves/sram.dat should be 8192 bytes")

    def valid(self, k):
        return self.data[k * self.SLOT + 0x3E5: k * self.SLOT + 0x3E7] == b"\xaa\x55"

    @staticmethod
    def checksum_ok(block):
        return sum(struct.unpack("<640H", bytes(block))) & 0xFFFF == 0x5A5A

    def fix_checksum(self, k):
        b = k * self.SLOT
        s = sum(struct.unpack_from("<639H", self.data, b)) & 0xFFFF
        struct.pack_into("<H", self.data, b + 0x4FE, (0x5A5A - s) & 0xFFFF)
        # mirror copy the game falls back to
        self.data[b + 0xF00: b + 0xF00 + self.SLOT] = self.data[b: b + self.SLOT]

    def summary(self, k):
        b = k * self.SLOT
        if not self.valid(k):
            return {"slot": k, "valid": False}
        return {"slot": k, "valid": True, "hearts": self.data[b + 0x36C] / 8, "progress": self.data[b + 0x3C5],
                "checksum_ok": self.checksum_ok(self.data[b: b + self.SLOT])}

    def save(self):
        bk = backup_once(self.path, ".editor-orig")
        write_atomic(self.path, bytes(self.data))
        return bk


# ----------------------------------------------------------------------------
# Quick-save states (saves/saveN.sav, F-keys)
# ----------------------------------------------------------------------------

class StateFile:
    def __init__(self, path):
        self.path = path
        self.data = bytearray(open(path, "rb").read())
        if len(self.data) < 32:
            raise ValueError("file too small")
        h = list(struct.unpack_from("<8I", self.data, 0))
        if h[0] != 1:
            raise ValueError("unknown quick-save version %d" % h[0])
        self.hdr = h
        off = 32 + h[2] + (h[6] if h[5] & 1 else 0)
        if off + h[6] != len(self.data):
            raise ValueError("unexpected quick-save layout")
        self.ram = off + h[6] - 4 - 0x20000      # 128 KB of SNES WRAM
        if self.ram < off:
            raise ValueError("quick-save too small")

    def r8(self, a):
        return self.data[self.ram + a]

    def r16(self, a):
        return struct.unpack_from("<H", self.data, self.ram + a)[0]

    def w8(self, a, v):
        self.data[self.ram + a] = v & 0xFF

    def w16(self, a, v):
        struct.pack_into("<H", self.data, self.ram + a, v & 0xFFFF)

    def location(self):
        return {"module": self.r8(0x10), "submodule": self.r8(0x11), "indoors": bool(self.r8(0x1B)),
                "room": self.r16(0xA0), "screen": self.r16(0x8A), "x": self.r16(0x22), "y": self.r16(0x20),
                "darkworld": bool(self.r8(0xF3CA) & 0x40), "replay": self.hdr[7] != 0,
                "entrance": self.r8(0x10E)}

    def save(self):
        # stop any recorded-input replay so the game doesn't override the edit
        struct.pack_into("<I", self.data, 5 * 4, self.hdr[5] & 1)
        struct.pack_into("<I", self.data, 7 * 4, 0)
        d = os.path.join(os.path.dirname(self.path), "editor-backups")
        os.makedirs(d, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        shutil.copy2(self.path, os.path.join(d, "%s.%s" % (os.path.basename(self.path), stamp)))
        write_atomic(self.path, bytes(self.data))


# ----------------------------------------------------------------------------
# Warp destinations
# ----------------------------------------------------------------------------

class World:
    def __init__(self, af):
        self.ent_rooms = af.words("kEntranceData_rooms")
        self.exit_rooms = af.words("kExitDataRooms")
        self.exit_screens = list(af.get("kExitData_ScreenIndex"))
        ow_area = af.words("kOverworld_Entrance_Area")
        ow_id = list(af.get("kOverworld_Entrance_Id"))
        self.ent_area = {}
        for a, e in zip(ow_area, ow_id):
            self.ent_area.setdefault(e, a)
        self.sp_rooms = af.words("kStartingPoint_rooms")

    @staticmethod
    def uses_cached_exit(room):
        return 0x100 <= room < 0x180 and room != 0x104

    def entrance_world(self, i):
        room = self.ent_rooms[i]
        if self.uses_cached_exit(room):
            return None             # leaving returns to wherever you came from: keep current world
        if i in self.ent_area:
            return 0x40 if self.ent_area[i] >= 0x40 else 0
        for k, r in enumerate(self.exit_rooms):
            if r == room:
                return 0x40 if self.exit_screens[k] >= 0x40 else 0
        return None

    def room_name(self, room):
        for i, r in enumerate(self.ent_rooms):
            if r == room:
                return ENTRANCE_NAMES[i]
        return None

    def destinations(self):
        out = []
        seen = set()
        for k, room in enumerate(self.exit_rooms):
            if room >= 0x180 or self.uses_cached_exit(room) or room in seen:
                continue
            seen.add(room)
            nm = self.room_name(room) or "Room 0x%X" % room
            sc = self.exit_screens[k]
            out.append({"id": "out:%d" % k, "kind": "outside", "name": "Outside " + nm,
                        "world": "Dark" if sc >= 0x40 else "Light", "detail": "overworld screen 0x%02X" % sc})
        for i, nm in enumerate(ENTRANCE_NAMES):
            room = self.ent_rooms[i]
            w = self.entrance_world(i)
            if self.uses_cached_exit(room):
                note = "leaving returns you to where you warped from"
            elif not any(r == room for r in self.exit_rooms) and room != 0x104:
                note = "inner room (no exit door)"
            else:
                note = "room 0x%X" % room
            out.append({"id": "in:%d" % i, "kind": "inside", "name": nm,
                        "world": {None: "Either", 0: "Light", 0x40: "Dark"}[w], "detail": note})
        return out

    def start_names(self):
        names = []
        for i, room in enumerate(self.sp_rooms):
            names.append(self.room_name(room) or "Room 0x%X" % room)
        return names

    def apply(self, st, dest_id):
        kind, idx = dest_id.split(":")
        idx = int(idx)
        st.w8(0x4AA, 0)            # death_var4
        st.w8(0x10A, 0)            # death_var5
        st.w8(0x1CE8, 0)           # choice_in_multiselect_box
        st.w8(0x11, 0)
        st.w8(0xB0, 0)
        if st.r8(0xF3CC) == 4:     # old-man follower forces the starting-point path
            st.w8(0xF3CC, 0)
        if kind == "in":
            st.w8(0x10, 6)         # Module_PreDungeon: load entrance
            st.w16(0x10E, idx)     # which_entrance
            w = self.entrance_world(idx)
            if w is not None:
                st.w8(0xF3CA, w)
            return {"world": w}
        else:
            room = self.exit_rooms[idx]
            st.w8(0x10, 8)         # Module08_OverworldLoad: exit to overworld via exit table
            st.w16(0xA0, room)
            st.w16(0x48E, room)
            st.w8(0x1B, 1)
            w = 0x40 if self.exit_screens[idx] >= 0x40 else 0
            st.w8(0xF3CA, w)
            return {"world": w}


# ----------------------------------------------------------------------------
# Enemy stats (zelda3.exe tables + kEnemyDamageData in the asset file)
# ----------------------------------------------------------------------------

WEAPONS = ["Boomerang", "Sword 1", "Sword 2", "Sword 3", "Sword 4", "Sword 5 (spin)", "Arrow", "Hookshot",
           "Bomb", "Silver arrow", "Powder", "Fire rod", "Ice rod", "Bombos", "Ether", "Quake"]
NUM_DAMAGE_SPRITES = 216


class EnemyTables:
    TABLES = ["kSpriteInit_Health", "kSpriteInit_BumpDamage", "kPlayerDamages", "kEnemyDamages"]

    def __init__(self, game_dir):
        self.exe = os.path.join(game_dir, "zelda3.exe")
        self.dat = os.path.join(game_dir, "zelda3_assets.dat")
        self.error = None
        self.offsets = {}
        self.reload()

    def _find(self):
        cands = [self.exe + ".orig", self.exe]
        size = os.path.getsize(self.exe)
        for c in cands:
            if not os.path.exists(c) or os.path.getsize(c) != size:
                continue
            blob = open(c, "rb").read()
            offs = {}
            for name in self.TABLES:
                sig = EXE_SIGNATURES[name]
                i = blob.find(sig)
                if i < 0 or blob.find(sig, i + 1) >= 0:
                    break
                offs[name] = i
            if len(offs) == len(self.TABLES):
                return offs
        return None

    def reload(self):
        self.error = None
        if not os.path.exists(self.exe):
            self.error = "zelda3.exe not found"
            return
        offs = self._find()
        if not offs:
            self.error = ("Couldn't locate the enemy tables in zelda3.exe (different build?). "
                          "Weapon damage can still be edited.")
        self.offsets = offs or {}
        exe = open(self.exe, "rb").read()
        self.vals = {}
        for name, off in self.offsets.items():
            self.vals[name] = bytearray(exe[off: off + len(EXE_SIGNATURES[name])])
        af = AssetFile(self.dat)
        self.damage_data = bytearray(af.get("kEnemyDamageData"))

    def weapon_class(self, sprite, weapon):
        i = sprite * 16 + weapon
        if i // 2 >= len(self.damage_data):
            return None
        b = self.damage_data[i // 2]
        return (b >> 4) if (i % 2 == 0) else (b & 0xF)

    def set_weapon_class(self, sprite, weapon, v):
        i = sprite * 16 + weapon
        j = i // 2
        if j >= len(self.damage_data):
            return
        v &= 0xF
        b = self.damage_data[j]
        self.damage_data[j] = ((v << 4) | (b & 0xF)) if i % 2 == 0 else ((b & 0xF0) | v)

    def to_json(self):
        exe_ok = bool(self.offsets)
        rows = []
        for s in range(243):
            rows.append({
                "id": s, "name": SPRITE_NAMES[s] if s < len(SPRITE_NAMES) else "%02X" % s,
                "hp": self.vals["kSpriteInit_Health"][s] if exe_ok else None,
                "bump": (self.vals["kSpriteInit_BumpDamage"][s] & 0xF) if exe_ok else None,
                "weapons": [self.weapon_class(s, w) for w in range(16)] if s < NUM_DAMAGE_SPRITES else None,
            })
        pd = [((v + 128) % 256) - 128 for v in self.vals["kPlayerDamages"]] if exe_ok else None
        return {"rows": rows, "weapons": WEAPONS, "exe_ok": exe_ok, "error": self.error,
                "playerDamages": pd, "enemyDamages": list(self.vals["kEnemyDamages"]) if exe_ok else None,
                "patched": os.path.exists(self.exe + ".orig") and open(self.exe, "rb").read() != open(self.exe + ".orig", "rb").read()}

    def apply(self, j):
        exe_ok = bool(self.offsets)
        for r in j.get("rows", []):
            s = int(r["id"])
            if exe_ok and r.get("hp") is not None:
                self.vals["kSpriteInit_Health"][s] = max(0, min(int(r["hp"]), 255))
            if exe_ok and r.get("bump") is not None:
                b = self.vals["kSpriteInit_BumpDamage"][s]
                self.vals["kSpriteInit_BumpDamage"][s] = (b & 0xF0) | (max(0, min(int(r["bump"]), 9)) & 0xF)
            if r.get("weapons") is not None and s < NUM_DAMAGE_SPRITES:
                for w, v in enumerate(r["weapons"]):
                    if v is not None:
                        self.set_weapon_class(s, w, max(0, min(int(v), 7)))
        if exe_ok and j.get("playerDamages"):
            for i, v in enumerate(j["playerDamages"][:30]):
                self.vals["kPlayerDamages"][i] = max(0, min(int(v), 127))
        if exe_ok and j.get("enemyDamages"):
            for i, v in enumerate(j["enemyDamages"][:128]):
                self.vals["kEnemyDamages"][i] = max(0, min(int(v), 255))

    def save(self):
        notes = []
        if self.offsets:
            exe = bytearray(open(self.exe, "rb").read())
            for name, off in self.offsets.items():
                exe[off: off + len(self.vals[name])] = self.vals[name]
            b = backup_once(self.exe)
            if b:
                notes.append(b)
            try:
                write_atomic(self.exe, bytes(exe))
            except PermissionError:
                raise ValueError("zelda3.exe is in use. Close the game, then save again.")
        af = AssetFile(self.dat)            # re-read so texture edits made meanwhile are kept
        af.blobs["kEnemyDamageData"] = bytes(self.damage_data)
        b = backup_once(self.dat)
        if b:
            notes.append(b)
        shutil.copy2(self.dat, self.dat + ".bak")
        write_atomic(self.dat, af.serialize())
        return notes

    def restore(self):
        restored = []
        if os.path.exists(self.exe + ".orig"):
            try:
                shutil.copy2(self.exe + ".orig", self.exe)
            except PermissionError:
                raise ValueError("zelda3.exe is in use. Close the game first.")
            restored.append("zelda3.exe")
        # only the enemy table inside the asset file is reset
        if os.path.exists(self.dat + ".orig"):
            orig = AssetFile(self.dat + ".orig")
            af = AssetFile(self.dat)
            af.blobs["kEnemyDamageData"] = orig.get("kEnemyDamageData")
            write_atomic(self.dat, af.serialize())
            restored.append("weapon damage table")
        self.reload()
        return restored


# ----------------------------------------------------------------------------
# Project
# ----------------------------------------------------------------------------

class Project:
    def __init__(self, game_dir):
        self.game_dir = os.path.abspath(game_dir)
        self.dat = os.path.join(self.game_dir, "zelda3_assets.dat")
        if not os.path.exists(self.dat):
            raise SystemExit("zelda3_assets.dat not found in %s (use --game DIR)" % self.game_dir)
        self.saves_dir = os.path.join(self.game_dir, "saves")
        self.sram_path = os.path.join(self.saves_dir, "sram.dat")
        self.world = World(AssetFile(self.dat))
        self.enemies = EnemyTables(self.game_dir)
        self.lock = threading.RLock()

    def meta(self):
        return {"game_dir": self.game_dir, "fields": field_meta(self.world.start_names()),
                "dungeons": DUNGEONS, "keyDungeons": KEY_DUNGEONS, "destinations": self.world.destinations(),
                "version": TOOL_VERSION}

    # -- save file --
    def sram(self):
        sf = SaveFile(self.sram_path)
        return {"exists": os.path.exists(self.sram_path),
                "slots": [dict(sf.summary(k), values=read_fields(sf.data, k * 0x500) if sf.valid(k) else None)
                          for k in range(3)]}

    def save_sram(self, slot, values):
        with self.lock:
            if not os.path.exists(self.sram_path):
                raise ValueError("saves/sram.dat doesn't exist yet - start a game first.")
            sf = SaveFile(self.sram_path)
            if not sf.valid(slot):
                raise ValueError("File %d is empty - create it in the game first." % (slot + 1))
            write_fields(sf.data, slot * 0x500, values)
            sf.fix_checksum(slot)
            bk = sf.save()
            return {"message": "Saved file %d." % (slot + 1) + (" Original kept as %s." % bk if bk else "")}

    # -- quick-saves --
    def states(self):
        out = []
        for p in sorted(glob.glob(os.path.join(self.saves_dir, "save*.sav")),
                        key=lambda p: int(re.sub(r"\D", "", os.path.basename(p)) or 0)):
            m = re.match(r"save(\d+)\.sav$", os.path.basename(p))
            if not m:
                continue
            n = int(m.group(1))
            key = ("F%d" % (n + 1)) if n < 10 else ("slot %d" % n)
            item = {"file": os.path.basename(p), "slot": n, "key": key,
                    "mtime": time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(p)))}
            try:
                st = StateFile(p)
                item["location"] = st.location()
                item["values"] = read_fields(st.data, st.ram + 0xF000)
                loc = item["location"]
                loc["room_name"] = self.world.room_name(loc["room"])
                if loc["module"] == 6 and loc["entrance"] < len(ENTRANCE_NAMES):
                    loc["pending"] = "inside " + ENTRANCE_NAMES[loc["entrance"]]
                elif loc["module"] == 8:
                    loc["pending"] = "outside " + (loc["room_name"] or "room 0x%X" % loc["room"])
            except Exception as e:
                item["error"] = str(e)
            out.append(item)
        return out

    def save_state(self, fname, values, warp):
        with self.lock:
            if not re.match(r"^save\d+\.sav$", fname):
                raise ValueError("bad file name")
            p = os.path.join(self.saves_dir, fname)
            st = StateFile(p)
            if values:
                write_fields(st.data, st.ram + 0xF000, values)
            msg = []
            if warp:
                st_mod = st.r8(0x10)
                r = self.world.apply(st, warp)
                msg.append("Warp set.")
                if st_mod not in (7, 9):
                    msg.append("(This quick-save wasn't taken during normal play, so the warp may misbehave. "
                               "Quick-save while walking around for best results.)")
                if r["world"] == 0x40 and not st.r8(0xF357):
                    msg.append("Note: no Moon Pearl - Link will be a bunny in the Dark World.")
            st.save()
            n = int(re.sub(r"\D", "", fname))
            key = "F%d" % (n + 1) if n < 10 else "its load key"
            msg.insert(0, "Saved %s. Press %s in the game to load it." % (fname, key))
            return {"message": " ".join(msg)}

    # -- enemies --
    def enemy_data(self):
        self.enemies.reload()
        return self.enemies.to_json()

    def save_enemies(self, j):
        with self.lock:
            self.enemies.reload()
            self.enemies.apply(j)
            notes = self.enemies.save()
            return {"message": "Enemy stats saved. Restart the game to use them." +
                    (" Backups: %s." % ", ".join(notes) if notes else "")}

    def restore_enemies(self):
        with self.lock:
            r = self.enemies.restore()
            return {"message": ("Restored: %s." % ", ".join(r)) if r else "Nothing to restore - no backups yet."}


# ----------------------------------------------------------------------------
# Web UI
# ----------------------------------------------------------------------------

def app_data_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "Zelda3GameEditor")
    os.makedirs(d, exist_ok=True)
    return d


def open_app_window(url):
    if os.name == "nt":
        import subprocess
        env = os.environ
        for base in (env.get("PROGRAMFILES(X86)"), env.get("PROGRAMFILES"), env.get("LOCALAPPDATA")):
            if not base:
                continue
            for c in (os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                      os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")):
                if os.path.exists(c):
                    try:
                        subprocess.Popen([c, "--app=" + url, "--window-size=1400,920"])
                        return
                    except OSError:
                        pass
    import webbrowser
    webbrowser.open(url)


def run_server(proj, port=0, open_browser=True, exit_when_closed=False):
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    html = HTML_PAGE.encode("utf-8")
    life = {"start": time.time(), "last": 0.0, "bye": None}

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, body, ctype="application/json"):
            if isinstance(body, (dict, list)):
                body = json.dumps(body).encode()
            elif isinstance(body, str):
                body = body.encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _route(self, method):
            life["last"] = time.time()
            u = urllib.parse.urlparse(self.path)
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}") if (method == "POST" and n) else {}
            try:
                p = u.path
                if p == "/" and method == "GET":
                    return self._send(200, html, "text/html; charset=utf-8")
                if p == "/api/ping":
                    return self._send(200, {"ok": True})
                if p == "/api/bye":
                    life["bye"] = time.time()
                    return self._send(200, {"ok": True})
                if p == "/api/meta":
                    return self._send(200, proj.meta())
                if p == "/api/sram":
                    return self._send(200, proj.sram())
                if p == "/api/sram/save":
                    return self._send(200, proj.save_sram(int(body["slot"]), body["values"]))
                if p == "/api/states":
                    return self._send(200, proj.states())
                if p == "/api/states/save":
                    return self._send(200, proj.save_state(body["file"], body.get("values"), body.get("warp")))
                if p == "/api/enemies":
                    return self._send(200, proj.enemy_data())
                if p == "/api/enemies/save":
                    return self._send(200, proj.save_enemies(body))
                if p == "/api/enemies/restore":
                    return self._send(200, proj.restore_enemies())
                return self._send(404, {"error": "not found"})
            except ValueError as e:
                return self._send(400, {"error": str(e)})
            except Exception as e:
                return self._send(500, {"error": "%s: %s" % (type(e).__name__, e)})

        def do_GET(self):
            self._route("GET")

        def do_POST(self):
            self._route("POST")

    srv = None
    if port == 0:
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", DEFAULT_PORT), H)
        except OSError:
            try:
                r = json.loads(urllib.request.urlopen("http://127.0.0.1:%d/api/meta" % DEFAULT_PORT, timeout=3).read())
                if os.path.normcase(r.get("game_dir", "")) == os.path.normcase(proj.game_dir):
                    if open_browser:
                        open_app_window("http://127.0.0.1:%d/" % DEFAULT_PORT)
                    print("Already running - opened the existing window.")
                    return
            except Exception:
                pass
    if srv is None:
        srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    url = "http://127.0.0.1:%d/" % srv.server_address[1]
    print("Zelda3 Game Editor running at %s" % url)
    print("Game folder: %s" % proj.game_dir)
    print("Close this window (or press Ctrl+C) to stop.")
    if exit_when_closed:
        def watchdog():
            while True:
                time.sleep(1)
                now = time.time()
                if not life["last"]:
                    if now - life["start"] > 180:
                        os._exit(0)
                    continue
                if life["bye"] and life["last"] <= life["bye"] + 0.01 and now - life["bye"] > 8:
                    os._exit(0)
                if now - life["last"] > 200:
                    os._exit(0)
        threading.Thread(target=watchdog, daemon=True).start()
    if open_browser:
        threading.Timer(0.3, lambda: open_app_window(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


HTML_PAGE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Zelda3 Game Editor</title>
<style>
:root{--bg:#14161a;--panel:#1c1f25;--panel2:#23272f;--panel3:#2a2f38;--line:#30353f;--text:#e4e6ea;--dim:#8d94a1;
--acc:#d8b74a;--acc2:#5aa469;--warn:#e0884a;--err:#e05a5a;--lw:#7fb069;--dw:#a07fd0;--mono:ui-monospace,Consolas,monospace}
*{box-sizing:border-box}html,body{height:100%;margin:0}
body{background:var(--bg);color:var(--text);font:14px/1.4 system-ui,Segoe UI,sans-serif;display:flex;flex-direction:column;overflow:hidden}
header{display:flex;align-items:center;gap:14px;padding:0 14px;border-bottom:1px solid var(--line);background:var(--panel);min-height:48px}
header h1{font-size:15px;margin:0;letter-spacing:.04em;color:var(--acc);font-weight:700;white-space:nowrap}
nav{display:flex;gap:2px;align-self:stretch}
nav button{background:none;border:0;border-bottom:2px solid transparent;border-radius:0;color:var(--dim);padding:0 14px;font-weight:600}
nav button.on{color:var(--text);border-bottom-color:var(--acc)}
header .path{color:var(--dim);font:12px var(--mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;text-align:right}
button,select,input{background:var(--panel2);color:var(--text);border:1px solid var(--line);border-radius:6px;padding:5px 9px;font:inherit}
input[type=number]{width:74px}
input[type=checkbox]{accent-color:var(--acc);width:16px;height:16px;margin:0}
button{cursor:pointer;white-space:nowrap}button:hover{border-color:#4a5160}button:disabled{opacity:.4;cursor:default}
button.primary{background:var(--acc);color:#1a1606;border-color:var(--acc);font-weight:600}
button.danger{border-color:#6b3434;color:#f0b0b0}
main{flex:1;min-height:0;display:flex}
.tab{flex:1;min-height:0;display:flex}.tab:not(.on){display:none!important}
.col{display:flex;flex-direction:column;min-height:0}
.scroll{overflow:auto}
.bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:9px 16px;border-bottom:1px solid var(--line);background:var(--panel)}
.bar .sp{flex:1}
.note{color:var(--dim);font-size:12.5px}
.banner{margin:12px 16px 0;padding:9px 12px;border-radius:6px;background:#2b2618;border:1px solid #4d4224;color:#e8d9a8;font-size:13px}
.banner.err{background:#2e1c1c;border-color:#5a2c2c;color:#f0c0c0}
.slots{display:flex;gap:8px}
.slot{padding:7px 12px;border-radius:7px;border:1px solid var(--line);background:var(--panel2);cursor:pointer;min-width:150px;text-align:left}
.slot.on{border-color:var(--acc);background:#3a3420}
.slot b{display:block;font-size:13px}.slot span{color:var(--dim);font-size:12px}
.form{display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:14px;padding:14px 16px 40px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:9px;padding:12px 14px}
.card h3{margin:0 0 10px;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--dim)}
.row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:3px 0}
.row label{flex:1}
.row select{max-width:190px}
.toggles{display:grid;grid-template-columns:1fr 1fr;gap:4px 14px}
.toggles label{display:flex;align-items:center;gap:7px;padding:2px 0;cursor:pointer}
.chg{outline:2px solid var(--warn);outline-offset:1px}
table{border-collapse:collapse}
.dtab td,.dtab th{padding:3px 8px;text-align:center}.dtab td:first-child,.dtab th:first-child{text-align:left}
.dtab th{color:var(--dim);font-weight:500;font-size:12px}
.dtab input[type=number]{width:52px}
/* quick-saves */
#stList{width:300px;border-right:1px solid var(--line);background:var(--panel)}
.st{padding:9px 12px;border-bottom:1px solid var(--line);cursor:pointer}
.st:hover{background:var(--panel2)}.st.on{background:#3a3420}
.st .k{font-weight:700;color:var(--acc);margin-right:6px}.st .t{color:var(--dim);font-size:12px}
.st .loc{font-size:12.5px;margin-top:2px}
.warp{display:grid;grid-template-columns:1fr;gap:8px}
.dests{max-height:300px;overflow:auto;border:1px solid var(--line);border-radius:7px;background:var(--panel2)}
.dest{display:flex;align-items:center;gap:8px;padding:5px 10px;cursor:pointer;border-bottom:1px solid #262a32}
.dest:hover{background:var(--panel3)}.dest.on{background:#3a3420}
.dest .n{flex:1}.dest .d{color:var(--dim);font-size:11.5px;white-space:nowrap}
.tag{font-size:10.5px;padding:1px 6px;border-radius:9px;border:1px solid var(--line);color:var(--dim);white-space:nowrap}
.tag.Light{color:var(--lw);border-color:#3d5a33}.tag.Dark{color:var(--dw);border-color:#4b3a66}
.tag.inside{color:#c9b38a}.tag.outside{color:#8ab6c9}
.steps{margin:0;padding-left:20px;color:var(--dim);font-size:13px}.steps li{margin:3px 0}
kbd{font:12px var(--mono);background:var(--panel3);border:1px solid var(--line);border-bottom-width:2px;border-radius:4px;padding:0 5px;color:var(--text)}
/* enemies */
#enTableWrap{flex:1;overflow:auto}
#enTable{font-size:12.5px;width:max-content}
#enTable th{position:sticky;top:0;background:var(--panel);z-index:2;padding:6px 4px;color:var(--dim);font-weight:500;border-bottom:1px solid var(--line);font-size:11px;white-space:nowrap}
#enTable th.w{writing-mode:vertical-rl;transform:rotate(180deg);height:92px;text-align:left;padding:4px 2px}
#enTable td{padding:2px 3px;border-bottom:1px solid #22262d}
#enTable td.nm{white-space:nowrap;padding-right:10px;position:sticky;left:0;background:var(--bg);z-index:1}
#enTable th.nm{left:0;z-index:3}
#enTable input{width:46px;padding:2px 4px;text-align:right}
#enTable input.w{width:30px;padding:2px 3px;text-align:center}
#enTable select{padding:2px 4px;font-size:12px}
#enTable tr:hover td{background:#1d2027}#enTable tr:hover td.nm{background:#1d2027}
.id{color:var(--dim);font:11px var(--mono);margin-right:6px}
details{margin:0 16px 14px}details summary{cursor:pointer;color:var(--dim);padding:8px 0}
.mini td{padding:2px}.mini input{width:52px}.mini th{color:var(--dim);font-weight:500;font-size:11.5px;padding:2px 6px}
#toast{position:fixed;right:16px;bottom:16px;max-width:520px;background:var(--panel2);border:1px solid var(--line);border-left:4px solid var(--acc2);border-radius:6px;padding:10px 14px;display:none;white-space:pre-wrap;box-shadow:0 6px 24px #0008;z-index:20}
#toast.err{border-left-color:var(--err)}#toast.warn{border-left-color:var(--warn)}
.empty{padding:40px;color:var(--dim)}
</style></head><body>
<header><h1>ZELDA3 GAME EDITOR</h1>
<nav><button data-tab="save" class="on">Save file</button><button data-tab="quick">Quick-saves &amp; warp</button><button data-tab="enemy">Enemies</button></nav>
<div class="path" id="gamedir"></div></header>
<main>
<!-- SAVE FILE -->
<section class="tab on col" id="tab-save" style="flex:1">
 <div class="bar"><div class="slots" id="slots"></div><span class="sp"></span>
  <button id="svMax">Max everything</button><button id="svRefill">Refill</button>
  <button id="svRevert">Revert</button><button id="svSave" class="primary" disabled>Save file</button></div>
 <div class="banner">Close the game before saving here. A running game keeps its own copy of the save and overwrites this file the next time it saves.</div>
 <div class="scroll" style="flex:1"><div id="svForm" class="form"></div></div>
</section>
<!-- QUICK SAVES -->
<section class="tab" id="tab-quick" style="flex:1">
 <div id="stList" class="col"><div class="bar"><b>Quick-saves</b><span class="sp"></span><button id="stReload">Reload</button></div><div class="scroll" id="stItems" style="flex:1"></div></div>
 <div class="col" style="flex:1;min-width:0">
  <div class="bar"><span id="stTitle" style="font-weight:600">—</span><span class="sp"></span>
   <button id="stMax">Max everything</button><button id="stRefill">Refill</button><button id="stRevert">Revert</button>
   <button id="stSave" class="primary" disabled>Save quick-save</button></div>
  <div class="scroll" style="flex:1" id="stBody"></div>
 </div>
</section>
<!-- ENEMIES -->
<section class="tab col" id="tab-enemy" style="flex:1">
 <div class="bar"><input type="search" id="enQ" placeholder="Filter (e.g. moblin, 41)" style="width:220px">
  <label class="note" style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="enOnly" checked> Hide items &amp; NPCs</label>
  <span class="note">All HP ×</span><input type="number" id="enMul" value="2" step="0.25" min="0" style="width:64px"><button id="enMulGo">Apply</button>
  <span class="sp"></span><button id="enRestore" class="danger">Restore originals</button><button id="enSave" class="primary" disabled>Save to game</button></div>
 <div id="enBanner"></div>
 <div id="enTableWrap"><table id="enTable"></table>
  <details><summary>Damage Link takes per contact class (in eighths of a heart: 8 = 1 heart)</summary><div id="pdTable"></div></details>
  <details><summary>Weapon damage table: damage each weapon deals for each vulnerability class (249 = turns into a fairy, 250 = turns into a slime, 251–255 = special effects)</summary><div id="edTable"></div></details>
 </div>
</section>
</main>
<div id="toast"></div>
<script>
const $=s=>document.querySelector(s);
const el=(t,a={},...c)=>{const e=document.createElement(t);for(const[k,v]of Object.entries(a)){if(k==='class')e.className=v;else if(k==='text')e.textContent=v;else if(k.startsWith('on'))e[k]=v;else e.setAttribute(k,v)}for(const x of c)if(x!=null)e.append(x);return e};
function toast(m,k){const t=$('#toast');t.textContent=m;t.className=k||'';t.style.display='block';clearTimeout(t._h);t._h=setTimeout(()=>t.style.display='none',k==='err'?10000:6000)}
async function api(p,body){const r=await fetch(p,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const j=await r.json().catch(()=>({error:'bad response'}));if(!r.ok)throw new Error(j.error||r.statusText);return j}
const clone=o=>JSON.parse(JSON.stringify(o));
const store={get(k,d){try{const v=localStorage.getItem('z3ge:'+k);return v===null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem('z3ge:'+k,JSON.stringify(v))}catch(e){}}};
let META=null;
const BOMB_CAP=[10,15,20,25,30,35,40,50],ARROW_CAP=[30,35,40,45,50,55,60,70];

/* ---------- tabs ---------- */
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
function showTab(t){document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));
 document.querySelectorAll('.tab').forEach(s=>s.classList.toggle('on',s.id==='tab-'+t));store.set('tab',t);
 if(t==='quick'&&!ST.loaded)loadStates();if(t==='enemy'&&!EN.loaded)loadEnemies()}

/* ---------- shared inventory form ---------- */
function optsList(o){if(Array.isArray(o))return Array.isArray(o[0])?o:o.map((l,i)=>[i,l]);return Object.entries(o).map(([k,l])=>[+k,l]).sort((a,b)=>a[0]-b[0])}
function isYesNo(f){return f.type==='sel'&&Array.isArray(f.opts)&&f.opts.length===2&&f.opts[1]==='Yes'}
function buildForm(root,vals,orig,onChange){
 root.innerHTML='';const groups={};
 for(const f of META.fields){(groups[f.group]=groups[f.group]||[]).push(f)}
 const mark=(node,k,d)=>node.classList.toggle('chg',JSON.stringify(vals[k])!==JSON.stringify(orig[k])&&d!==false);
 const set=(k,v,node)=>{vals[k]=v;if(node)mark(node,k);onChange()};
 for(const [g,fs] of Object.entries(groups)){
  const card=el('div',{class:'card'},el('h3',{text:g}));
  if(g==='Items'){const tg=el('div',{class:'toggles'});
   for(const f of fs){if(isYesNo(f)){const cb=el('input',{type:'checkbox'});cb.checked=!!vals[f.key];mark(cb,f.key);cb.onchange=()=>set(f.key,cb.checked?1:0,cb);tg.append(el('label',{},cb,f.label))}}
   card.append(tg);for(const f of fs)if(!isYesNo(f))card.append(fieldRow(f));}
  else if(f0bits(fs)){for(const f of fs)card.append(bitsBlock(f))}
  else for(const f of fs)card.append(fieldRow(f));
  root.append(card)}
 // dungeon card
 const tb=el('table',{class:'dtab'},el('tr',{},el('th',{text:'Dungeon'}),el('th',{text:'Map'}),el('th',{text:'Compass'}),el('th',{text:'Big key'}),el('th',{text:'Keys'})));
 vals.dungeons.forEach((d,i)=>{const od=orig.dungeons[i];const tr=el('tr',{},el('td',{text:d.name}));
  for(const k of['map','compass','bigkey']){const cb=el('input',{type:'checkbox'});cb.checked=d[k];const m=()=>cb.classList.toggle('chg',d[k]!==od[k]);m();cb.onchange=()=>{d[k]=cb.checked;m();onChange()};tr.append(el('td',{},cb))}
  if(d.keys===null)tr.append(el('td',{class:'note',text:'shared'}));else{const n=el('input',{type:'number',min:0,max:99,value:d.keys});const m=()=>n.classList.toggle('chg',d.keys!==od.keys);m();n.oninput=()=>{d.keys=Math.max(0,Math.min(99,+n.value||0));m();onChange()};tr.append(el('td',{},n))}
  tb.append(tr)});
 root.append(el('div',{class:'card',style:'grid-column:1/-1'},el('h3',{text:'Dungeon items'}),tb));
 function f0bits(fs){return fs.length===1&&fs[0].type==='bits8'}
 function fieldRow(f){const row=el('div',{class:'row'},el('label',{text:f.label}));let inp;
  if(f.type==='sel'){inp=el('select');const list=optsList(f.opts);let has=false;
   for(const[v,l]of list){inp.append(el('option',{value:v,text:l}));if(v===vals[f.key])has=true}
   if(!has)inp.append(el('option',{value:vals[f.key],text:'Other ('+vals[f.key]+')'}));
   inp.value=vals[f.key];inp.onchange=()=>set(f.key,+inp.value,inp)}
  else if(f.type==='hearts'){inp=el('input',{type:'number',min:0,max:f.opts,step:f.key==='health'?0.5:1,value:vals[f.key]});inp.oninput=()=>set(f.key,Math.max(0,Math.min(f.opts,+inp.value||0)),inp)}
  else if(f.type==='bits8'){inp=bitsInline(f)}
  else{inp=el('input',{type:'number',min:0,max:f.opts,value:vals[f.key]});inp.oninput=()=>set(f.key,Math.max(0,Math.min(f.opts,Math.round(+inp.value||0))),inp)}
  mark(inp,f.key);row.append(inp);return row}
 function bitsInline(f){const w=el('span',{style:'display:flex;gap:3px'});
  for(let b=0;b<8;b++){const cb=el('input',{type:'checkbox',title:'bit '+b+' (0x'+(1<<b).toString(16)+')'});cb.checked=!!(vals[f.key]&(1<<b));
   cb.onchange=()=>{vals[f.key]=cb.checked?(vals[f.key]|(1<<b)):(vals[f.key]&~(1<<b));w.classList.toggle('chg',vals[f.key]!==orig[f.key]);onChange()};w.append(cb)}
  return w}
 function bitsBlock(f){const tg=el('div',{class:'toggles',style:'grid-template-columns:1fr'});
  for(const[bit,l]of optsList(f.opts)){const cb=el('input',{type:'checkbox'});cb.checked=!!(vals[f.key]&bit);
   const m=()=>cb.classList.toggle('chg',!!(vals[f.key]&bit)!==!!(orig[f.key]&bit));m();
   cb.onchange=()=>{vals[f.key]=cb.checked?(vals[f.key]|bit):(vals[f.key]&~bit);m();onChange()};tg.append(el('label',{},cb,l))}
  return tg}
}
function refill(v){v.health=v.hearts;v.magic=128;v.bombs=BOMB_CAP[Math.min(7,v.bombup)];v.arrows=ARROW_CAP[Math.min(7,v.arrowup)];return v}
function maxAll(v){Object.assign(v,{sword:4,shield:3,armor:2,gloves:2,boots:1,flippers:1,pearl:1,bow:4,boomerang:2,hookshot:1,mushroom:2,firerod:1,icerod:1,bombos:1,ether:1,quake:1,lamp:1,hammer:1,flute:3,net:1,book:1,somaria:1,byrna:1,cape:1,mirror:2,bottle1:6,bottle2:5,bottle3:8,bottle4:4,hearts:20,magicup:2,rupees:999,bombup:7,arrowup:7});return refill(v)}

/* ---------- save file tab ---------- */
const SV={data:null,slot:0,vals:null,orig:null};
async function loadSram(keepSlot){const j=await api('/api/sram');SV.data=j;
 const valid=j.slots.filter(s=>s.valid).map(s=>s.slot);if(!keepSlot||!j.slots[SV.slot].valid)SV.slot=valid.length?valid[0]:0;renderSlots();openSlot(SV.slot)}
function renderSlots(){const box=$('#slots');box.innerHTML='';
 SV.data.slots.forEach(s=>{const b=el('button',{class:'slot'+(s.slot===SV.slot?' on':'')},el('b',{text:'File '+(s.slot+1)}),
  el('span',{text:s.valid?`${s.hearts} hearts · ${['New game','Uncle\'s sword','Zelda rescued','Agahnim beaten'][s.progress]||'progress '+s.progress}${s.checksum_ok?'':' · checksum bad'}`:'Empty'}));
  b.disabled=!s.valid;b.onclick=()=>{if(dirtySv()&&!confirm('Discard unsaved changes to this file?'))return;SV.slot=s.slot;renderSlots();openSlot(s.slot)};box.append(b)})}
function openSlot(k){const s=SV.data.slots[k];const f=$('#svForm');
 if(!s||!s.valid){SV.vals=null;f.innerHTML='';f.append(el('div',{class:'empty',text:SV.data.exists?'No save files yet. Start a game and save once, then come back.':'saves/sram.dat not found. Start a game and save once, then come back.'}));updSv();return}
 SV.vals=clone(s.values);SV.orig=clone(s.values);buildForm(f,SV.vals,SV.orig,updSv);updSv()}
function dirtySv(){return SV.vals&&JSON.stringify(SV.vals)!==JSON.stringify(SV.orig)}
function updSv(){$('#svSave').disabled=!dirtySv();['#svMax','#svRefill','#svRevert'].forEach(s=>$(s).disabled=!SV.vals)}
$('#svMax').onclick=()=>{maxAll(SV.vals);buildForm($('#svForm'),SV.vals,SV.orig,updSv);updSv()};
$('#svRefill').onclick=()=>{refill(SV.vals);buildForm($('#svForm'),SV.vals,SV.orig,updSv);updSv()};
$('#svRevert').onclick=()=>openSlot(SV.slot);
$('#svSave').onclick=async()=>{try{const r=await api('/api/sram/save',{slot:SV.slot,values:SV.vals});toast(r.message);await loadSram(true)}catch(e){toast('Save failed: '+e.message,'err')}};

/* ---------- quick-saves tab ---------- */
const ST={loaded:false,list:[],cur:null,vals:null,orig:null,warp:null,q:''};
async function loadStates(){ST.loaded=true;ST.list=await api('/api/states');renderStates();
 const keep=ST.list.find(s=>s.file===ST.cur);openState(keep?keep.file:(ST.list[0]&&ST.list[0].file))}
function locText(l){if(!l)return'';const w=l.darkworld?'Dark World':'Light World';
 if(l.pending)return'Warp pending → '+l.pending+' (load it in the game)';
 return l.indoors?`Inside ${l.room_name||'room 0x'+l.room.toString(16)} · ${w}`:`Overworld screen 0x${l.screen.toString(16).padStart(2,'0')} · ${w}`}
function renderStates(){const box=$('#stItems');box.innerHTML='';
 if(!ST.list.length){box.append(el('div',{class:'empty'},'No quick-saves yet.',el('br'),el('br'),'In the game press ',el('kbd',{text:'Shift'}),' + ',el('kbd',{text:'F1'}),' to make one, then click Reload.'));return}
 for(const s of ST.list){const d=el('div',{class:'st'+(s.file===ST.cur?' on':'')},el('div',{},el('span',{class:'k',text:s.key}),el('span',{class:'t',text:s.mtime+' · '+s.file})),
  el('div',{class:'loc',text:s.error?('Unreadable: '+s.error):locText(s.location)}));d.onclick=()=>{if(dirtySt()&&!confirm('Discard unsaved changes?'))return;openState(s.file)};box.append(d)}}
function openState(file){ST.cur=file;ST.warp=null;renderStates();const body=$('#stBody');body.innerHTML='';
 const s=ST.list.find(x=>x.file===file);
 const help=el('div',{class:'card',style:'margin:14px 16px 0'},el('h3',{text:'How it works'}),el('ol',{class:'steps'},
  el('li',{},'In the game, press ',el('kbd',{text:'Shift'}),' + ',el('kbd',{text:'F1'}),' (… ',el('kbd',{text:'F10'}),') to quick-save while walking around.'),
  el('li',{},'Pick that quick-save here, change items or choose a warp destination, then click ',el('b',{text:'Save quick-save'}),'.'),
  el('li',{},'Back in the game, press ',el('kbd',{text:'F1'}),' (the same slot) to load it — you are warped instantly.')));
 if(!s){ST.vals=null;body.append(help);$('#stTitle').textContent='—';updSt();return}
 $('#stTitle').textContent=`${s.key} · ${s.file}`;
 if(s.error){ST.vals=null;body.append(el('div',{class:'banner err',text:'This quick-save could not be read: '+s.error}));updSt();return}
 ST.vals=clone(s.values);ST.orig=clone(s.values);
 const warpCard=el('div',{class:'card',style:'margin:14px 16px 0'},el('h3',{text:'Warp'}),
  el('div',{class:'note',style:'margin-bottom:8px',text:'Currently: '+locText(s.location)+(s.location.replay?' · (input replay will be switched off)':'')}));
 const q=el('input',{type:'search',placeholder:'Search destinations (e.g. kakariko, palace, outside)',style:'width:100%',value:ST.q});
 const kindSel=el('select',{},el('option',{value:'',text:'All'}),el('option',{value:'outside',text:'Overworld (outside a building)'}),el('option',{value:'inside',text:'Inside (entrances)'}));
 kindSel.value=store.get('kind','');
 const list=el('div',{class:'dests'});const chosen=el('div',{class:'note',text:'No warp selected — only item changes will be saved.'});
 const clearBtn=el('button',{text:'Clear warp',onclick:()=>{ST.warp=null;draw();updSt()}});
 function draw(){list.innerHTML='';const t=q.value.trim().toLowerCase();const kd=kindSel.value;
  for(const d of META.destinations){if(kd&&d.kind!==kd)continue;if(t&&!(d.name+' '+d.world+' '+d.kind+' '+d.detail).toLowerCase().includes(t))continue;
   const r=el('div',{class:'dest'+(ST.warp===d.id?' on':'')},el('span',{class:'tag '+d.kind,text:d.kind==='outside'?'Overworld':'Inside'}),el('span',{class:'n',text:d.name}),
    el('span',{class:'d',text:d.detail}),el('span',{class:'tag '+d.world,text:d.world==='Either'?'Same world':d.world+' World'}));
   r.onclick=()=>{ST.warp=d.id;draw();updSt()};list.append(r)}
  const d=META.destinations.find(x=>x.id===ST.warp);
  chosen.textContent=d?`Warp to: ${d.name} (${d.kind==='outside'?'overworld':'inside'}, ${d.world==='Either'?'same world':d.world+' World'})`+
   (d.world==='Dark'&&!ST.vals.pearl?' — no Moon Pearl: Link will be a bunny there.':''):'No warp selected — only item changes will be saved.';
  chosen.style.color=d?'var(--acc)':''}
 q.oninput=()=>{ST.q=q.value;draw()};kindSel.onchange=()=>{store.set('kind',kindSel.value);draw()};draw();
 warpCard.append(el('div',{class:'warp'},el('div',{style:'display:flex;gap:8px'},q,kindSel),list,el('div',{style:'display:flex;gap:10px;align-items:center'},chosen,el('span',{style:'flex:1'}),clearBtn)));
 const form=el('div',{class:'form'});body.append(warpCard,form,help);buildForm(form,ST.vals,ST.orig,updSt);updSt()}
function dirtySt(){return ST.vals&&(ST.warp||JSON.stringify(ST.vals)!==JSON.stringify(ST.orig))}
function updSt(){$('#stSave').disabled=!dirtySt();['#stMax','#stRefill','#stRevert'].forEach(s=>$(s).disabled=!ST.vals);$('#stSave').textContent=ST.warp?'Save quick-save + warp':'Save quick-save'}
$('#stReload').onclick=()=>loadStates();
$('#stMax').onclick=()=>{maxAll(ST.vals);openFormOnly()};$('#stRefill').onclick=()=>{refill(ST.vals);openFormOnly()};
function openFormOnly(){buildForm(document.querySelector('#stBody .form'),ST.vals,ST.orig,updSt);updSt()}
$('#stRevert').onclick=()=>openState(ST.cur);
$('#stSave').onclick=async()=>{const changed=JSON.stringify(ST.vals)!==JSON.stringify(ST.orig);
 try{const r=await api('/api/states/save',{file:ST.cur,values:changed?ST.vals:null,warp:ST.warp});toast(r.message,/Note|misbehave/.test(r.message)?'warn':'');await loadStates()}catch(e){toast('Save failed: '+e.message,'err')}};

/* ---------- enemies tab ---------- */
const EN={loaded:false,data:null,orig:null};
async function loadEnemies(){EN.loaded=true;try{EN.data=await api('/api/enemies')}catch(e){$('#enBanner').innerHTML='';$('#enBanner').append(el('div',{class:'banner err',text:e.message}));return}
 EN.orig=clone(EN.data);renderEnemies()}
function dmgOf(w,c){const t=EN.data.enemyDamages;return t?t[w*8+c]:null}
function dmgLabel(v){return v===null?'?':v===0?'immune':v===249?'→ fairy':v===250?'→ slime':v>=251?'special':v}
function bumpLabel(c){const p=EN.data.playerDamages;return p?`${c}: ${p[c*3]/8}/${p[c*3+1]/8}/${p[c*3+2]/8} ♥`:String(c)}
function renderEnemies(){const D=EN.data,O=EN.orig;const ban=$('#enBanner');ban.innerHTML='';
 if(D.error)ban.append(el('div',{class:'banner',text:D.error}));
 if(D.patched)ban.append(el('div',{class:'banner',text:'zelda3.exe already has edited enemy stats (the original is kept as zelda3.exe.orig).'}));
 const t=$('#enTable');t.innerHTML='';
 const hr=el('tr',{},el('th',{class:'nm',text:'Enemy'}),el('th',{text:'HP'}),el('th',{text:'Contact damage (class: green/blue/red mail)'}));
 D.weapons.forEach(w=>hr.append(el('th',{class:'w',text:w})));t.append(el('thead',{},hr));
 const tb=el('tbody');t.append(tb);
 const q=$('#enQ').value.trim().toLowerCase(),only=$('#enOnly').checked;
 D.rows.forEach((r,i)=>{const o=O.rows[i];
  const name=r.name.replace(/^[0-9A-F]+[-:]/i,'')||'(unnamed)';
  if(q&&!(name+' '+r.id.toString(16)+' '+r.name).toLowerCase().includes(q))return;
  if(only&&!q&&(r.id>=0xD8||(r.hp===0&&(!r.weapons||r.weapons.every(x=>x===0)))))return;
  const tr=el('tr');tr.append(el('td',{class:'nm'},el('span',{class:'id',text:r.id.toString(16).toUpperCase().padStart(2,'0')}),name));
  if(r.hp===null)tr.append(el('td',{class:'note',text:'—'}));else{const n=el('input',{type:'number',min:0,max:255,value:r.hp});const m=()=>n.classList.toggle('chg',r.hp!==o.hp);m();
   n.oninput=()=>{r.hp=Math.max(0,Math.min(255,Math.round(+n.value||0)));m();updEn()};tr.append(el('td',{},n))}
  if(r.bump===null)tr.append(el('td',{class:'note',text:'—'}));else{const s=el('select');for(let c=0;c<10;c++)s.append(el('option',{value:c,text:bumpLabel(c)}));s.value=r.bump;const m=()=>s.classList.toggle('chg',r.bump!==o.bump);m();
   s.onchange=()=>{r.bump=+s.value;m();updEn()};tr.append(el('td',{},s))}
  for(let w=0;w<16;w++){if(!r.weapons){tr.append(el('td'));continue}
   const n=el('input',{type:'number',class:'w',min:0,max:7,value:r.weapons[w]});
   const tip=()=>n.title=`${D.weapons[w]}: vulnerability class ${r.weapons[w]} → ${dmgLabel(dmgOf(w,r.weapons[w]))} damage`;tip();
   const m=()=>n.classList.toggle('chg',r.weapons[w]!==o.weapons[w]);m();
   n.oninput=()=>{r.weapons[w]=Math.max(0,Math.min(7,Math.round(+n.value||0)));m();tip();updEn()};tr.append(el('td',{},n))}
  tb.append(tr)});
 // global tables
 const pd=$('#pdTable');pd.innerHTML='';if(D.playerDamages){const tt=el('table',{class:'mini'},el('tr',{},el('th',{text:'Class'}),el('th',{text:'Green mail'}),el('th',{text:'Blue mail'}),el('th',{text:'Red mail'})));
  for(let c=0;c<10;c++){const tr=el('tr',{},el('th',{text:c}));for(let a=0;a<3;a++){const i=c*3+a;const n=el('input',{type:'number',min:0,max:127,value:D.playerDamages[i]});const m=()=>n.classList.toggle('chg',D.playerDamages[i]!==O.playerDamages[i]);m();
   n.oninput=()=>{D.playerDamages[i]=Math.max(0,Math.min(127,Math.round(+n.value||0)));m();updEn()};tr.append(el('td',{},n))}tt.append(tr)}pd.append(tt)}
 const ed=$('#edTable');ed.innerHTML='';if(D.enemyDamages){const tt=el('table',{class:'mini'});const h=el('tr',{},el('th',{text:'Weapon \\ class'}));for(let c=0;c<8;c++)h.append(el('th',{text:c}));tt.append(h);
  D.weapons.forEach((wn,w)=>{const tr=el('tr',{},el('th',{text:wn,style:'text-align:left'}));for(let c=0;c<8;c++){const i=w*8+c;const n=el('input',{type:'number',min:0,max:255,value:D.enemyDamages[i]});const m=()=>n.classList.toggle('chg',D.enemyDamages[i]!==O.enemyDamages[i]);m();
   n.oninput=()=>{D.enemyDamages[i]=Math.max(0,Math.min(255,Math.round(+n.value||0)));m();updEn()};tr.append(el('td',{},n))}tt.append(tr)});ed.append(tt)}
 updEn()}
function dirtyEn(){return EN.data&&JSON.stringify(EN.data)!==JSON.stringify(EN.orig)}
function updEn(){$('#enSave').disabled=!dirtyEn()}
$('#enQ').oninput=()=>EN.data&&renderEnemies();$('#enOnly').onchange=()=>EN.data&&renderEnemies();
$('#enMulGo').onclick=()=>{const k=+$('#enMul').value;if(!(k>=0))return;let n=0;
 EN.data.rows.forEach(r=>{if(r.hp&&r.id<0xD8){r.hp=Math.max(1,Math.min(255,Math.round(r.hp*k)));n++}});renderEnemies();toast(`Multiplied HP of ${n} enemies by ${k}. Not saved yet.`)};
$('#enSave').onclick=async()=>{try{const D=EN.data;const r=await api('/api/enemies/save',{rows:D.rows,playerDamages:D.playerDamages,enemyDamages:D.enemyDamages});toast(r.message);EN.loaded=false;await loadEnemies()}catch(e){toast('Save failed: '+e.message,'err')}};
$('#enRestore').onclick=async()=>{if(!confirm('Put back the original enemy stats (from the backups made on first save)?'))return;try{const r=await api('/api/enemies/restore',{});toast(r.message);EN.loaded=false;await loadEnemies()}catch(e){toast(e.message,'err')}};

/* ---------- startup ---------- */
window.addEventListener('beforeunload',e=>{if(dirtySv()||dirtySt()||dirtyEn()){e.preventDefault();e.returnValue=''}});
window.addEventListener('pagehide',()=>navigator.sendBeacon('/api/bye',''));
setInterval(()=>fetch('/api/ping').catch(()=>{}),5000);
(async()=>{try{META=await api('/api/meta');$('#gamedir').textContent=META.game_dir;await loadSram(false);showTab(store.get('tab','save'))}catch(e){toast('Failed to load: '+e.message,'err')}})();
</script></body></html>
"""


def show_error(msg):
    try:
        with open(os.path.join(app_data_dir(), "error.log"), "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except Exception:
        pass
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, msg, "Zelda3 Game Editor", 0x10)
            return
        except Exception:
            pass
    print(msg, file=sys.stderr)


def main(argv):
    game = os.path.dirname(TOOL_DIR)
    port, no_browser, windowed = 0, False, False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--game":
            game = argv[i + 1]; i += 2; continue
        if a == "--port":
            port = int(argv[i + 1]); i += 2; continue
        if a == "--no-browser":
            no_browser = True; i += 1; continue
        if a == "--windowed":
            windowed = True; i += 1; continue
        if a in ("-h", "--help"):
            print(__doc__); return 0
        i += 1
    try:
        proj = Project(game)
    except SystemExit as e:
        if windowed:
            show_error(str(e)); return 2
        raise
    except Exception as e:
        if windowed:
            show_error("Could not load the game files in %s:\n\n%s: %s" % (game, type(e).__name__, e)); return 2
        raise
    run_server(proj, port, not no_browser, exit_when_closed=windowed)
    return 0


if __name__ == "__main__":
    if "--windowed" in sys.argv:
        try:
            sys.exit(main(sys.argv[1:]))
        except Exception:
            import traceback
            show_error("Unexpected error:\n\n" + traceback.format_exc())
            sys.exit(2)
    sys.exit(main(sys.argv[1:]))
